<template>
  <div class="interactive flex h-[90vh] justify-evenly items-center">
    <CircleChart/>
    <InfoBox/>
  </div>
</template>

<script setup>
import CircleChart from '../components/CircleChart.vue'
import InfoBox from '../components/InfoBox.vue';
</script>

<style lang="css" scoped>

</style>